#=============================================================================
# PROGRAMMER: Kenan Kaaki
# PANTHER ID: 6271587
#
# CLASS: COP4830
# SECTION: RVC1225
# SEMESTER: Summer 2022
# CLASSTIME:  WED 5:30PM -6:30PM
# CERTIFICATION: I understand FIU’s academic policies, and I certify that this 
#                work is my own and that none of it is the work of any other person.
#=============================================================================

#Question 1---------------
library(readxl)
ModelData <- read_excel("CAP4830_HW2_Data.xlsx")
View(ModelData)

#Question 2--------------

names(ModelData)
#model.frame(ModelData) #used for testing purposes
#data.frame(ModelData)  #used for testing purposes

#Question 3-----------------

model1 <- lm(UNRATE_PCH ~ DFII10_PCH + CPILFESL_PCH + XTEITT01CNM156S_PCH 
                        + DCOILWTICO_PCH + PCOPPUSDM_PCH + PCE_PCH 
                        + WPU101_PCH + GPDIC1_PCH + RRVRUSQ156N_PCH,
                        data = ModelData)


print(model1)
summary(model1)

#Question 4----------------
#in word doc

#Question 5----------------

plot(density(model1$residuals),
    main = "Density Plot: Model1 Residuals",
    ylab = "Frequency")

polygon(density(model1$residuals), col = "blue")

#Question 6-----------------

plot(model1)
shapiro.test(model1$residuals)

#Question 7-----------------

model2 <- lm(UNRATE_PCH ~ DFII10_PCH + CPILFESL_PCH 
             + XTEITT01CNM156S_PCH  
             + DCOILWTICO_PCH + PCE_PCH + RRVRUSQ156N_PCH,
             data = ModelData)

print(model2)
summary(model2)

#question 8-----------------

#answer is in PDF/WORD DOC

#question 9------------------

#distPred <- predict(model2, ModelData)
#actuals_preds <- data.frame(cbind(index = seq(1: nrow(ModelData)), 
#                                  actuals= ModelData$Price,
#                                  predicteds=distPred)) 

#print(actuals_preds)

model2_pred <- mean(model2$residuals^2)
model2_pred
#cor(actuals_preds$actuals,actuals_preds$predicteds) 

#question 10------------------

model3 <- lm(UNRATE_PCH ~ XTEITT01CNM156S_PCH + CPILFESL_PCH + PCE_PCH,
             data = ModelData)
summary(model3)

#question 11-------------------

model4 <- sample(1:nrow(ModelData), 0.6 * nrow(ModelData))

summary(model4)

#question 12-------------------
distPred <- predict(trainingModel, testData)  
head(distPred)

#question 13-------------------

acutal_preds <- data.frame(cbind(index = seq(1: nrow(testData)),
                                 actuals = testData$UNRATE_PCH,
                                 predicteds=distPred))

cor(actuals_preds$actuals, actuals_preds$predicteds)

library(ggplot2)


gg <- ggplot(data = actuals_preds, aes(index))  + 
  geom_point(aes(y = actuals), color = "red") + 
  geom_point(aes(y = predicteds), color = "blue") +
  labs( title = "Actual vs Predicted Values")
gg

model2_pred <- mean(model4$residuals^2)
model2_pred

#questions 14------------------

library(caret)

controlled <- trainControl(method = "cv", number = 10)

k10_model <- train(UNRATE_PCH ~ DFII10_PCH + DCOILWTICO_PCH + PCE_PCH,
                   data = ModelData, method = "lm", trControl = controlled)

print(k10_model)

