import streamlit as st
import requests as rq
import pandas as pd
import numpy as np

st.set_page_config(
    page_title="Air Pollution Project",
    layout="wide",
    menu_items={'Get Help': 'https://docs.streamlit.io/',
                'About': "Welcome to Air Pollution. Developed by Luis Garcia"}
)

supported_Countries_API = 'http://api.airvisual.com/v2/countries?key=34d8d610-ba92-4364-ad9d-eeac87cc3df0'
supported_States_API = 'https://api.airvisual.com/v2/states?country={}&key=34d8d610-ba92-4364-ad9d-eeac87cc3df0'
supported_Cities_API = 'https://api.airvisual.com/v2/cities?state={}&country={}&key=34d8d610-ba92-4364-ad9d-eeac87cc3df0'
supported_Air_API = 'https://api.airvisual.com/v2/city?city={0}&state={1}&country={2}&key=34d8d610-ba92-4364-ad9d-eeac87cc3df0'


# CREATE MAP
@st.cache
def map_creator(latitude, longitude):
    df = pd.DataFrame(
        np.array([[latitude, longitude]]),
        columns=['lat', 'lon'])
    return df


# GATHER AIR QUALITY API
@st.cache
def get_air(city, state, country):
    air_info = rq.get(supported_Air_API.format(city, state, country))
    air_JSON = air_info.json()
    return air_JSON


# CREATE DROPDOWN MENU OF CITIES
@st.cache
def cities_find(state, country):
    scit_info = rq.get(supported_Cities_API.format(state, country))
    scit_json = scit_info.json()
    city_list = [" "]

    for number in range(len(scit_json["data"])):
        city_list.append(scit_json['data'][number]['city'])

    return city_list


# CREATE DROPDOWN MENU OF STATES
@st.cache
def states_find(country):
    ss_info = rq.get(supported_States_API.format(country))
    ss_JSON = ss_info.json()
    state_list = [" "]

    for number in range(len(ss_JSON["data"])):
        state_list.append(ss_JSON['data'][number]['state'])

    return state_list


# CREATE DROPDOWN MENU OF COUNTRIES
@st.cache
def find_country():
    s_cInfo = rq.get(supported_Countries_API)
    sc_JSON = s_cInfo.json()
    countries = [" "]
    for n in range(140):
        countries.append(sc_JSON["data"][n]["country"])
    return countries


option = st.selectbox(
    "Select Country",
    find_country()
)
if option != " ":
    state = st.selectbox(
        "Select State",
        states_find(option)
    )

    if state != " ":
        city = st.selectbox(
            "Select City",
            cities_find(state, option)
        )

        if city != " ":
            latitude = get_air(city, state, option)['data']['location']['coordinates'][0]
            longitude = get_air(city, state, option)['data']['location']['coordinates'][1]
            st.map(map_creator(longitude, latitude))
            st.write("Today is " + get_air(city, state, option)['data']['current']["pollution"]['ts'])
            st.info("The humidity is: " + str(get_air(city, state, option)['data']['current']["weather"]['hu']))
            st.info("The Air Quality is: " + str(get_air(city, state, option)['data']['current']["pollution"]['aqius']))
